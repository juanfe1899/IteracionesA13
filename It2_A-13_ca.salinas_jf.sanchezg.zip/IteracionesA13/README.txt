﻿Iteracion #2


Juan Felipe Sanchez Guerrero - 201618582
Grupo A-13


Sistemas Transacionales
ISIS 2304
2018-2

*

Instalacion:

Para la instalacion del aplicativo importe el proyecto en Eclipse
y ejecute las pruebas destinadas en la carpeta src/test/java

