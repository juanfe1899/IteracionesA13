package uniandes.isis2304.superAndes.persistencia;

import java.sql.Timestamp;
import java.util.List;
import java.math.BigDecimal;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import uniandes.isis2304.superAndes.negocio.Factura;
import uniandes.isis2304.superAndes.persistencia.PersistenciaSuperandes;

/**
 * Clase que encapsula los m�todos que hacen acceso a la base de datos para el concepto Factura de SuperAndes
 * N�tese que es una clase que es s�lo conocida en el paquete de persistencia
 * 
 * @author Geovanny Andres Gonzalez
 */

class SQLFacturas {

	/* ****************************************************************
	 * 			Constantes
	 *****************************************************************/
	/**
	 * Cadena que representa el tipo de consulta que se va a realizar en las sentencias de acceso a la base de datos
	 * Se renombra acá para facilitar la escritura de las sentencias
	 */

	private final static String SQL = PersistenciaSuperandes.SQL;

	/* ****************************************************************
	 * 			Atributos
	 *****************************************************************/
	/**
	 * El manejador de persistencia general de la aplicación
	 */
	private PersistenciaSuperandes pp;

	/* ****************************************************************
	 * 			M�todos
	 *****************************************************************/
	/**
	 * Constructor
	 * @param pp - El Manejador de persistencia de la aplicaci�n
	 */
	
	public SQLFacturas (PersistenciaSuperandes pp)
	{
		this.pp = pp;
	}
	
	/**
	 * Agrega una nueva factura a la base de datos
	 * @param pm Administrador de la unidad de persistencia
	 * @param fecha fehca en la que se realiza la factura
	 * @param total precio total de la factura
	 * @param id identificador de dicha factura
	 * @param idSucursal identificador de la sucursal que crea la factura
	 * @param idCliente identificador del cliente al que se le hace la factura
	 * @return El n�mero de tuplas insertadas
	 */
	
	public long agregarFactura(PersistenceManager pm, Timestamp fecha, int total, long id, long idSucursal, long idCliente) {
		System.out.println("Crear Query de insercion");	
		Query qFactura = pm.newQuery(SQL, "INSERT INTO " + pp.darTablaFacturas() + "(id, fecha, total, id_cliente, id_sucursal) values (?,?,?,?,?)");
		qFactura.setParameters(id, fecha, total, idCliente, idSucursal);
		System.out.println("Inicio de ejecucion de Query" + "Consulta: " + "INSERT INTO " + pp.darTablaFacturas() + "(id, fecha, total, id_cliente, id_sucursal) values (?,?,?,?,?)");
		long tuplas = (long) qFactura.executeUnique();
		System.out.println("[SQLFactura] Tuplas modificadas: " + tuplas);
		return tuplas;
	}
	
	/**
	 * Elimina una Factura de la base de datos
	 * @param pm Administrador de la unidad de persistencia
	 * @param id identificador de la Factura a eliminar.
	 * @return El numero de tuplas eliminadas.
	 */
	
	public long eliminarFactura(PersistenceManager pm, int id) {
		Query q = pm.newQuery(SQL, "DELETE FROM " + pp.darTablaFacturas() + " WHERE id = ?");
        q.setParameters(id);
        return (long) q.executeUnique();           
	}
	
	/**
	 * Crea y ejecuta la sentencia SQL para encontrar la informaci�n de una Factura de la 
	 * base de datos de SuperAndes, por su id
	 * @param pm - El manejador de persistencia
	 * @param id - El identificador de la Factura
	 * @return El objeto Factura que tiene el identificador dado
	 */
	
	public Factura darFactura(PersistenceManager pm, int id) {
		Query q = pm.newQuery(SQL, "SELECT * FROM " + pp.darTablaFacturas () + " WHERE id = ?");
        q.setParameters(id);

        Object result = q.executeUnique();        
        Object[] resultados = (Object[]) result;
        
        //Casteo - ruego a Dios Padre que sirva, ya estoy que no puedo del cansancio, llevo 6 horas con eso.
        long idFactura =  ((BigDecimal) resultados[0]).longValue ();
        Timestamp fecha = (Timestamp) resultados[1];
        int total = ((BigDecimal) resultados[2]).intValue();
        long idCliente =((BigDecimal) resultados[3]).longValue ();
        long idSucursal = ((BigDecimal) resultados[4]).longValue ();
		Factura rsp = new Factura(fecha, idFactura, total, idCliente, idSucursal);      
         
        return rsp;
	}
	
	/**
	 * Crea y ejecuta la sentencia SQL para encontrar la informaci�n de LAS Facturas de la 
	 * base de datos de SuperAndes
	 * @param pm - El manejador de persistencia
	 * @return Una lista de objetos Factura
	 */
	
	public List<Factura> darFactura (PersistenceManager pm)
	{
		Query q = pm.newQuery(SQL, "SELECT * FROM " + pp.darTablaFacturas ());
		q.setResultClass(Factura.class);
		List<Factura> executeList = (List<Factura>) q.executeList();		
		return executeList;
	}
	
	
	/**
	 * Crea y ejecuta la sentencia SQL para encontrar la informaci�n de el dinero recogido por cada sucursal de la 
	 * base de datos de superAndes.
	 * @param pm - El manejador de persistencia
	 * @return Una lista de arreglos de objetos, de tama�o 2. Los elementos del arreglo corresponden a la suma total recolectada 
	 * y el identificador de la sucursal que le corresponde
	 */
	public List<Object> darTotalDineroRecolectado (PersistenceManager pm, Timestamp fechaInicio, Timestamp fechaFin)
	{
	    String sql = "SELECT SUM(TOTAL) AS DINERO, ID_SUCURSAL AS SUCURSAL";
	    sql += " FROM " + pp.darTablaFacturas ();
	    sql += " WHERE FECHA BETWEEN ? AND ?";
	    sql	+= " GROUP BY ID_SUCURSAL";
	    
		
	    Query q = pm.newQuery(SQL, sql);
		q.setParameters(fechaInicio, fechaFin);
		return q.executeList();
	}
	
}
