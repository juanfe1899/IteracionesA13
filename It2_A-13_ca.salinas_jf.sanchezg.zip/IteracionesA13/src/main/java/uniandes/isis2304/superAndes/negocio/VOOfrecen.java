package uniandes.isis2304.superAndes.negocio;

public interface VOOfrecen {

}
